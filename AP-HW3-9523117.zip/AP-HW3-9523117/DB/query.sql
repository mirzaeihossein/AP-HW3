--------Q1----------
select * from Users where phone='09120000001';
--------Q2----------
update Users
set email='apstudent2019@gmail.com'
where phone='09120000001';
---------Q3----------
select telegram_id from channel where id in(select channel_id from channelmembership where
	 user_id=(select id from Users where phone='09120000001'));
---------Q4----------
select count(distinct user_id)
	from channelmembership
	where channel_id in(select id from channel where telegram_id='@aut_ap_2019');
--------Q5-----------
select email from Users where phone like '0935_%_%';
--------Q6-----------
select phone from Users where telegram_id in(select blocked_user_id from blockUser where 
	blocker_user_id=(select telegram_id from Users where phone='09120000001') and 
	(created_at between now() - interval '1' month and now()));
--------Q7-----------
SELECT email FROM users WHERE telegram_id in(SELECT creator_id FROM Channel WHERE id in(SELECT channel_id FROM
	channelmembership WHERE user_id in(SELECT id FROM users WHERE email = 'apstudent2019@gmail.com') and 
	channel_id in (SELECT channel_id FROM channelmembership GROUP BY channel_id HAVING COUNT(*) > 3 )));
--------Q8----------
select message_text from Message where ((sender_id = '@sHDiV4RHs' and reciever_id='@amir.jahanshahi') or 
	(sender_id='@amir.jahanshahi' and reciever_id = '@sHDiV4RHs')) order by id desc limit 10 ;

delete from Message where ((sender_id = '@sHDiV4RHs' and reciever_id='@amir.jahanshahi') or 
	(sender_id='@amir.jahanshahi' and reciever_id = '@sHDiV4RHs'));
--------Q9----------
SELECT phone FROM Users WHERE telegram_id in (SELECT creator_id FROM channel WHERE updated_at NOT BETWEEN now() - INTERVAL '1' month AND now() );

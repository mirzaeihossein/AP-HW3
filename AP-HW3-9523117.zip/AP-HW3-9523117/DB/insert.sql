-----Q1---------
insert into users(id,telegram_id,phone,email,first_name,last_name,
	verification_code,profile_picture_url,created_at,updated_at)
	values(0,'@amir.jahanshahi','09120000001','amir@gmail.com','amir',
		'jahanshahi','951234','goodpic',now(),now());



insert into users(id,telegram_id,phone,email,first_name,last_name,
	verification_code,profile_picture_url,created_at,updated_at)
	values(1,'@sHDiV4RHs','09355467893','sHDiV4RHs@gmail.com','Mehdi',
		'Naseri','967526','good',now(),now());

insert into users(id,telegram_id,phone,email,first_name,last_name,
	verification_code,profile_picture_url,created_at,updated_at)
	values(2,'@hossein.mir','09197950654','hossein@gmail.com','hossein',
		'mir','977526','like',now(),now());	
insert into users(id,telegram_id,phone,email,first_name,last_name,
	verification_code,profile_picture_url,created_at,updated_at)
	values(3,'@barazandeh','09192626674','milad@gmail.com','milad',
		'barazandeh','978526','likely',now(),now());
-----Q3 & Q4---------
insert into Channel(id,telegram_id,title‬‬,info,creator_id,created_at,updated_at)
	values(0,'@apchannel','Apchannel','for ap student','@hossein.mir',now(),now());


insert into Channel(id,telegram_id,title‬‬,info,creator_id,created_at,updated_at)
	values(1,'@aut_ap_2019','aut_ap_2019','for ap good student','@barazandeh',now(),now());

insert into ChannelMembership(user_id,channel_id,crated_at)
	values((select id from users where phone='09120000001'),
		(select id from Channel where telegram_id='@apchannel'),now());

insert into ChannelMembership(user_id,channel_id,crated_at)
	values((select id from users where phone='09120000001'),
		(select id from Channel where telegram_id='@aut_ap_2019'),now());

insert into ChannelMembership(user_id,channel_id,crated_at)
	values((select id from users where phone='09355467893'),
		(select id from Channel where telegram_id='@aut_ap_2019'),now());

insert into ChannelMembership(user_id,channel_id,crated_at)
	values((select id from users where phone='09192626674'),
		(select id from Channel where telegram_id='@aut_ap_2019'),now());

insert into ChannelMembership(user_id,channel_id,crated_at)
	values((select id from users where phone='09197950654'),
		(select id from Channel where telegram_id='@aut_ap_2019'),now());	

insert into ChannelMembership(user_id,channel_id,crated_at)
	values((select id from users where phone='09355467893'),
		(select id from Channel where telegram_id='@apchannel'),now());
----------Q6---------
insert into blockuser(blocker_user_id,blocked_user_id,crated_at)
	values((select telegram_id from users where phone='09120000001'),
		(select telegram_id from users where phone='09355467893'),now());
---------Q8----------
insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(0,'@sHDiV4RHs','@amir.jahanshahi','text','salam ostad.....!',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(1,'@sHDiV4RHs','@amir.jahanshahi','text','khobid ostad.....?',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(2,'@amir.jahanshahi','@sHDiV4RHs','text','khobid shoma?che khabar.....?',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(3,'@amir.jahanshahi','@sHDiV4RHs','text','soal baraye bacheha tarh kardid?',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(4,'@sHDiV4RHs','@amir.jahanshahi','text','az kodom ghesmat?',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(5,'@amir.jahanshahi','@sHDiV4RHs','text','database workshop....',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(6,'@amir.jahanshahi','@sHDiV4RHs','text','say konid soalye sakhti bedid....',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(7,'@sHDiV4RHs','@amir.jahanshahi','text','chera ostad?',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(8,'@amir.jahanshahi','@sHDiV4RHs','text','mikham ke khob yad begiran',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(9,'@amir.jahanshahi','@sHDiV4RHs','text','bayad in dars ha ro khob balad bashand...',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(10,'@sHDiV4RHs','@amir.jahanshahi','text','chashm ostad....',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(11,'@sHDiV4RHs','@amir.jahanshahi','text','amry nist ostad....?',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(12,'@amir.jahanshahi','@sHDiV4RHs','text','dar panahe hagh...',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(13,'@sHDiV4RHs','@amir.jahanshahi','text','khodahafez ostad....',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(14,'@sHDiV4RHs','@hossein.mir','text','bah bah ....',now(),now());

insert into Message(id,sender_id,reciever_id,message_type,message_text,created_at,updated_at)
	values(15,'@sHDiV4RHs','@hossein.mir','text','bah che khabar....',now(),now());
--------Q9----------	
UPDATE channel SET updated_at  = '2018-02-11 00:48:18.641029' where creator_id = '@hossein.mir';


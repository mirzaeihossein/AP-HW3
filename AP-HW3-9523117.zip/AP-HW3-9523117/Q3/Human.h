#include<string>

class Human{
public:
	//constructors
Human(std::string FirstName,std::string LastName,int HairColor,int EyeColor,int Age,bool Gender,int NumberOfChilderen);//constructor
Human(const Human& h);//copy constructor
Human();//default constructor
//get functions
std::string getFirstName();
std::string getLastName();
bool getGender();
int getHairColor();
int getEyeColor();
int getAge();
int getNumberOfChilderen();
//set functions
void setFirstName(std::string);//set first Name
void setNumberOfChilderen();
//operators
bool operator<(Human& p);
bool operator==(Human& p);
bool operator!=(Human& p);
Human* operator++(int);
Human* operator++();
Human* operator+(Human& p);
Human* operator=(Human& p);
//pointer to mother & father & spouse & child & childeren
Human* father{nullptr};
Human* mother{nullptr};
Human* spouse{nullptr};
Human* child{nullptr};
Human** childeren{new Human*[1]};
//bool function
bool isChildOf(Human*);
bool isFatherOf(Human*);
bool isMotherOf(Human*);
//show function
void printChilderen();
private:
//general charecter
std::string firstName;
std::string lastName{};
int hairColor{};
int eyeColor{};
int age{};
bool gender{};
int numberOfChilderen{};
static inline int random{2};

};
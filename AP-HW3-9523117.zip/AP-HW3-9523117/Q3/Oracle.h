#include<string>
#include"Human.h"

class Oracle 
{
public:
Oracle(std::string);
bool marry(Human*,Human*);
void setChild(Human*,Human*,Human*);
private:
std::string Name{};
};
#include<iostream>
//#include"Human.h"
#include"Oracle.h"


int main()
{
Human* p1{new Human{"ALI","BAHADORI",4,3,25,0,0}};
Human* p2{new Human{"BAHAR","SHAMS",1,2,22,1,0}};


Oracle o1{"shervin"};
//married couple
o1.marry(p1,p2);

//use of marry function
std::cout << "(p1->spouse).firstname : " << (p1->spouse)->getFirstName() << std::endl;
std::cout << "(p2->spouse).firstname : " << (p2->spouse)->getFirstName() << std::endl;
std::cout << std::endl;

//creating new person
Human* p3{};
p3=((*p1)+(*p2));

//seting firstname of newborn
if(p3->getGender())
p3->setFirstName("Mahshid");
else
p3->setFirstName("Farshid");

//show childeren of P1
std::cout << "Childeren of P1 : ";
p1->printChilderen();
std::cout << std::endl;

//use of setfirsname function 

std::cout << "p3->getFirstName (name of newborn)  : " << p3->getFirstName() << std::endl;
std::cout << "((p3->mother)->getFirstName (mother of newborn) : " << (p3->mother)->getFirstName() << std::endl;
std::cout << "((p3->father)->getFirstName (father of newborn) : " << (p3->father)->getFirstName() << std::endl;
std::cout << std::endl;
//increasing the age of newborn 
(*p3)++;
std::cout << "p3->getAge : " << p3->getAge() << std::endl;
std::cout << std::endl;

Human* p4{new Human{"SHAHIN","REZAEI",0,5,58,1,1}};
Human* p5{new Human{"FARHAD","BAHADORI",0,6,63,0,1}};

o1.setChild(p1,p4,p5);

std::cout << "((p1->father)->getFirstName (father of p1) : " << (p1->father)->getFirstName() << std::endl;
std::cout << "((p1->mother)->getFirstName (mother of newborn) : " << (p1->mother)->getFirstName() << std::endl;
std::cout << std::endl;


	return 0;
}
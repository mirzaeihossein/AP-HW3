#include"Oracle.h"
#include<iostream>

Oracle::Oracle(std::string name)
{
	Name=name;
}
bool Oracle::marry(Human* p1,Human* p2)//check thay are married
{
	if( (p1->spouse != nullptr ) || (p2->spouse != nullptr) )
	{
		std::cout << "They can not marry" << std::endl;
		return false;
	}
	if( (p1->spouse == nullptr) && (p2->spouse == nullptr) )
	{
		if((p1->getAge() > 18) && (p2->getAge() > 18))
		{
			p1->spouse = p2;
			p2->spouse = p1;
			return true;
		}
		else 
			std::cout << "They can not marry" << std::endl;
		return false;
	}
	else
		return false;
}
void Oracle::setChild(Human* p1,Human* p2,Human* p3)//set a person as child
{
	p1->mother = p2;//set father and mother
	p1->father = p3;
	p2->child = p1;
	p3->child = p1;

	Human** oldchild1{new Human*[(*p2).getNumberOfChilderen()]};
	Human** oldchild2{new Human*[(*p3).getNumberOfChilderen()]};

	for(int i{}; i < (*p2).getNumberOfChilderen();i++)
	{
		oldchild2[i]=p2->childeren[i];
		oldchild1[i]=p3->childeren[i];
	}
	delete[] p2->childeren;
	delete[] p3->childeren;
	
	(*p2).setNumberOfChilderen();
	(*p3).setNumberOfChilderen();

	p2->childeren = new Human*[(*p3).getNumberOfChilderen()];
	p3->childeren = new Human*[(*p2).getNumberOfChilderen()];
	for(int i{}; i < (*p2).getNumberOfChilderen() ; i++)
	{	
		if(i < (*p2).getNumberOfChilderen() - 1)
		{
		p2->childeren[i] = oldchild1[i];
		p3->childeren[i] = oldchild2[i];
		}
		if(i == (*p2).getNumberOfChilderen() - 1)
		{
			p2->childeren[i]=p1;
			p3->childeren[i]=p1;
		}
	}
	delete[] oldchild2;
	delete[] oldchild1;
}	











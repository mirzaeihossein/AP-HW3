#include"Human.h"
#include<iostream>
#include<string>
#include<stdlib.h>
#include<random>
#include<vector>
//constructors
Human::Human(std::string FirstName1,std::string LastName1,int HairColor1,int EyeColor1,int 
	Age1,bool Gender1,int NumberOfChilderen1) //constructor
{
	//std::cout << "constructor" << std::endl;
	firstName=FirstName1;
	lastName=LastName1;
	hairColor=HairColor1;
	eyeColor=EyeColor1;
	age=Age1;
	gender=Gender1;
	numberOfChilderen=NumberOfChilderen1;
}
Human::Human(const Human& h) //copy constructor
{
	//std::cout << "copy constructor" << std::endl;
	firstName=h.firstName;
	lastName=h.lastName;
	hairColor=h.hairColor;
	eyeColor=h.eyeColor;
	age=h.age;
	gender=h.gender;
	numberOfChilderen=h.numberOfChilderen;
}
Human::Human() //default constructor
{
	//std::cout << "default constructor" << std::endl;
	firstName="";
	lastName="";
	hairColor=0;
	eyeColor=0;
	age=0;
	gender=1;
	numberOfChilderen=0;
}
// set function
void Human::setFirstName(std::string s)
{
	firstName=s;
}
void Human::setNumberOfChilderen()
{
	numberOfChilderen++;
}
//get functions
std::string Human::getFirstName()
{
	return firstName;
}
std::string Human::getLastName()
{
	return lastName;
}
int Human::getHairColor()
{
	return hairColor;
}
int Human::getEyeColor()
{
	return eyeColor;
}
int Human::getAge()
{
	return age;
}
bool Human::getGender()
{
	return gender;
}
int Human::getNumberOfChilderen()
{
	return numberOfChilderen;
}
//operators
bool Human::operator<(Human& p)
{
	return getAge() < p.getAge();
}
bool Human::operator==(Human& p)
{
	if((firstName==p.firstName) && (lastName==p.lastName) && (hairColor==p.hairColor) &&
	 (eyeColor==p.eyeColor) && (age==p.age) && (gender==p.gender) && (numberOfChilderen==p.numberOfChilderen))
		return true;
	else 
		return false;
}
bool Human::operator!=(Human& p)
{
	if((firstName!=p.firstName) && (lastName!=p.lastName) && (hairColor!=p.hairColor) &&
	 (eyeColor!=p.eyeColor) && (age!=p.age) && (gender!=p.gender) && (numberOfChilderen!=p.numberOfChilderen))
		return true;
	else 
		return false;
}
Human* Human::operator++(int){
	Human* copy{this};
	++(age);
	return copy;
}
Human* Human::operator++(){
 age++;
 return this;
}
Human* Human::operator+(Human& p)
{

	random++;
	Human* H{new Human{}};//new human
	if(*this->spouse == p)
	{	
	(*H).firstName="***Pleas Set a Name for your BABY***";
	(*H).lastName=this->lastName;
	(*H).age=0;
	(*H).numberOfChilderen=0;
	
	if(random % 2 == 1)
	{
		(*H).hairColor = this->hairColor;
		(*H).eyeColor = this->eyeColor;
		(*H).gender = this->gender;
	}
	if(random % 2 == 0)
	{
		(*H).hairColor = p.hairColor;
		(*H).eyeColor = p.eyeColor;
		(*H).gender = p.gender;

	}
	
	if(p.getGender() == true)//set father and mother
	H->mother = &p;
	else
	H->father = &p;
	if(this->getGender() == false)
	H->father = this;
	else
	H->mother = this;

	p.child = H;
	this->child = H;

	Human** oldchild1{new Human*[numberOfChilderen]};//copy old childeren and push new child
	Human** oldchild2{new Human*[numberOfChilderen]};

	for(int i{}; i < numberOfChilderen;i++)
	{
		oldchild2[i]=this->childeren[i];
		oldchild1[i]=p.childeren[i];
	}
	delete[] p.childeren;
	delete[] this->childeren;
	
	(p.numberOfChilderen)++;
	(numberOfChilderen)++;

	this->childeren = new Human*[numberOfChilderen];
	p.childeren = new Human*[p.numberOfChilderen];
	for(int i{}; i < numberOfChilderen ; i++)
	{	
		if(i < numberOfChilderen - 1)
		{
		this->childeren[i] = oldchild1[i];
		p.childeren[i] = oldchild2[i];
		}
		if(i == numberOfChilderen - 1)
		{
			this->childeren[i]=H;
			p.childeren[i]=H;
		}
	}
	delete[] oldchild2;
	delete[] oldchild1;

	return H;
 	}
 	else{ 
 		std::cout << "They are not spouse " << std::endl;
 		delete[] H;
 		return nullptr;
	}
}
Human* Human::operator=(Human& p)
{
	delete[] this;
	Human* H{new Human};
	(*H).firstName=p.firstName;
	(*H).lastName=p.lastName;
	(*H).hairColor=p.hairColor;
	(*H).eyeColor=p.eyeColor;
	(*H).age=p.age;
	(*H).gender=p.gender;
	(*H).numberOfChilderen=p.numberOfChilderen;

	return H;
}
//bool function
bool Human::isChildOf(Human* p)
{
	if(p->child == this)
		return true;
	else 
		return false;
}
bool Human::isFatherOf(Human* p)
{
	if(this == p->father)
		return true;
	else 
		return false;
}
bool Human::isMotherOf(Human* p)
{
	if(p->mother == this)
		return true;
	else
		return false;
}
//show function
void Human::printChilderen()
{	
	for(int i{};i < numberOfChilderen;i++)
	{
		if(i == numberOfChilderen -1)
			std::cout << (this->childeren[i])->getFirstName() << std::endl;
			else
			std::cout << (this->childeren[i])->getFirstName() << "," ; 
	}
}













#include<iostream>


class Myvec
{
public:
int size{};
int capacity{};
Myvec();
~Myvec();
Myvec(const Myvec& v);
Myvec(Myvec&& v);
void push_back(int);
void pop_back();
void show();
Myvec operator+(const Myvec& v);
Myvec operator*(const Myvec& v);
Myvec& operator=(const Myvec& v);
Myvec& operator=(Myvec&& v);
bool operator<(const Myvec& v) const;
bool operator==(const Myvec& v) const;
int Mag() const;




private:
int* arr;
static inline int k{1};	
};
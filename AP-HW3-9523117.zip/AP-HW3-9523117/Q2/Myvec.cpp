#include"Myvec.h"
#include<iostream>
#include<math.h>

Myvec::Myvec()//constructor
{
	size=0;
	capacity=0;
	arr = new int[capacity];//new array with length capacity
}
Myvec::Myvec(const Myvec& v)//copy constructor
{
	size = v.size;
	capacity = v.capacity;
	arr = new int[capacity];//new array with length v.capacity
	for(int i{};i < size;i++)//copy v.arr in new array
		arr[i]=v.arr[i];
}
Myvec::Myvec(Myvec&& v)//move constructor
{
	size = v.size;
	capacity = v.capacity;
	arr = v.arr;
	v.arr=nullptr;
}
void Myvec::push_back(int index)// push_back
{
	int* arr1;//array that use for copy
	arr1=new int[size];
	for(int i{};i<size;i++)
	{
		arr1[i]=arr[i];
	}
	if(size==0)
	{
		k=1;
	}
	size++;//increase length of array
	if(size < std::pow(2,k))
		capacity=(std::pow(2,k));
	if(size == std::pow(2,k))
	{
		capacity=(std::pow(2,k));
		k++;
	}
	delete[] arr;//delete *this
	arr=new int[capacity];//new array
	for(int i{};i < size-1;i++)
	{
		arr[i]= arr1[i];
	}
	delete[] arr1;
	arr[size-1]=index;//push_back index
}
void Myvec::show()//show array
{
	for(int i{};i < size;i++)
	{
		if(i==size-1)
			std::cout << arr[size-1] << std::endl;
		else
			std::cout << arr[i] << ",";
	}
}
int Myvec::Mag() const // magnitude of an array
{
	int mag{};
	for(int i{};i < size;i++)
	{
		mag += (std::pow(arr[i],2));
	}
	mag=std::pow(mag,0.5);
return mag;	
}
void Myvec::pop_back() // pop_back
{
	size--;//decrease length of array
	int* arr1{};
	arr1=new int[size];
	for(int i{}; i < size ;i++)
	{
		arr1[i]=arr[i];
	}
	delete[] arr;
	if(size == std::pow(2,k-1))//determine capacity
	{
		k--;
		capacity=(std::pow(2,k));
	}
	arr=new int[capacity];
	for(int i{};i < size ; i++)
	{
		arr[i]=arr1[i];
	}
	delete[] arr1;
}
Myvec Myvec::operator+(const Myvec& v)//operator +
{
	Myvec vec;
	if(size != v.size)
	{
		std::cout << "*for suming they shod be same length *" << std::endl;
	}
	if(size == v.size)
	{
		for(int i{};i < size ;i++)
		{
			vec.push_back(this->arr[i]+v.arr[i]);//add v.arr to this.arr
		}

	}
return vec;
}
Myvec Myvec::operator*(const Myvec& v)//operator * 
{
	Myvec vec;
	if(size != v.size)
	{
		std::cout << "*for product they shod be same length *" << std::endl;
	}
	if(size == v.size)
	{
		for(int i{};i < size ;i++)
		{
			vec.push_back(this->arr[i] * v.arr[i]);//multiple v.arr to this.arr
		}

	}
	return vec;
}
Myvec& Myvec::operator=(const Myvec& v)//operator = copy vesion
{
	
	delete[] arr;
	size=v.size;
	capacity=v.capacity;
	arr=new int[size];
	for(int i{};i < v.size;i++)
		arr[i]=v.arr[i];
	
	return *this;
}
Myvec& Myvec::operator=(Myvec&& v)// operator = move version
{
	delete[] arr;
	size=v.size;
	capacity=v.capacity;
	arr=v.arr;
	v.arr=nullptr;
	return *this;
}
bool Myvec::operator<(const Myvec& v) const //operator < 
{
 return Mag()< v.Mag();
}
bool Myvec::operator==(const Myvec& v) const//operator ==
{
	if(size != v.size)
	{
		std::cout <<"for comparsion they should be same length" << std::endl;
		return false;
	}
	for(int i{};i < size;i++)
	 if(arr[i] != v.arr[i])
	 	return false;
return true;
}
Myvec::~Myvec() // destructor
{
	delete[] arr;
}



























#include<iostream>
#include"Myvec.h"
#include<utility>

int main()
{

	Myvec v{};//make an object
	v.push_back(5);
	v.push_back(6);
	v.push_back(6);
	v.push_back(6);
	v.push_back(6);
	v.push_back(6);
	v.push_back(6);
	std::cout << "v array : " << std::endl;
	v.show();// use show 
	std::cout << std::endl;
	v.pop_back();
	v.pop_back();
	v.pop_back();
	v.pop_back();
	std::cout << "v array after use of pop_back : " << std::endl;
	v.show();
	std::cout << std::endl;
	Myvec v2{};
	v2.push_back(5);
	v2.push_back(6);
	v2.push_back(6);
	std::cout << "v2 array : " << std::endl;
	v2.show();
	std::cout << std::endl;
	std::cout << "v2 Mag : " << v2.Mag() << std::endl;//use mag func
	std::cout << std::endl;
	Myvec v3{};
	std::cout << "use of operator + (v2+v)" << std::endl;
	v3=v2+v;//use operator+
	v3.show();
	std::cout << std::endl;
	v3=v2*v;//use operator*
	v3.show();
	std::cout << "use operator * (v2*v)" << std::endl;
	std::cout << std::endl;
	std::cout << "use operator == " << std::endl;
	if(v  == v2)
	{
		std::cout << "They are same" << std::endl;
	}
	std::cout << std::endl;
	std::cout << "v3.size : " << v3.size << "  " << "v3.capacity : " << v3.capacity << std::endl;
	return 0;
}

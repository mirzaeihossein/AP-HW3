#include<iostream>
#include<math.h>
#include<bits/stdc++.h>
class Maxheap
{
public:
Maxheap(int* arr1,int);
Maxheap();
Maxheap(const Maxheap& h);
void Max_Heapify(int i);
void build_Max_Heapify(int* arr);
int leftchild(int i);
int rightchild(int i);
int parent(int i);
void printArray();
void Heapsort();
int getHeight();
int Max();
void Delete();
void add(int i);
int operator[](int i);
friend std::ostream &operator<<(std::ostream &os,const Maxheap & h)//define operator << as friend
{
	for(int i{};i < std::ceil(log2(h.N+1));i++){
		for(int j{};(j < std::pow(2,i)) && (j+std::pow(2,i) <= (h.N));j++){
			std::cout << h.arr[j+ (int)std::pow(2,i) - 1] << "," ;
		}
		std::cout << std::endl;
	}
	return os;
}
private:
int N{};
int* arr{};
static inline int count{};


};

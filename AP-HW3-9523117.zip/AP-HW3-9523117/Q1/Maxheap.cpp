#include"Maxheap.h"
#include<iostream>
#include<iomanip>
#include<math.h>
#include<bits/stdc++.h>


Maxheap::Maxheap(int* arr1,int n) //constructor
{
	N=n;
	arr=new int[50];//dynamic array
	arr=arr1;
	build_Max_Heapify(arr);
}
Maxheap::Maxheap()
{
	arr=new int[0];
}
void Maxheap::Max_Heapify(int i)//this part write by algoritm that was in clrs
{
	int largest{i};
	int left{2*i +1};
	int right{2*i +2};
	if( (left < N) && (arr[left] > arr[largest]) )
		largest=left;
	else
		largest=i;
	if( (right < N) && (arr[right] > arr[largest]) )
	{	
		largest=right;
	}
	if(i != largest)
	{
	std::swap(arr[i],arr[largest]);
	Max_Heapify(largest);
	}
}
void Maxheap::build_Max_Heapify(int* arr)//build maxheap
{

	for(int i{(N/2)-1};i >-1;i--)
	{
		Max_Heapify(i);
	}

}

Maxheap::Maxheap(const Maxheap& h)//copy constructor
{
	N=h.N;
	arr=new int[100];
	for(int i{};i < N;i++)
		arr[i]=h.arr[i];
}
int Maxheap::parent(int i)//return parent of i
{
	if(i==0)
	{
		std::cout << "This node is head of the tree and its value ==> ";
		return arr[i];
	}
	if( (i>0) && (i%2)==0)
	{
		std::cout << "The parent of this node has value ==> ";
		return arr[(i/2)-1];
	}
	if( (i>0) && (i%2)==1)
	{
		std::cout << "The parent of this node has value ==> ";
		return arr[i/2];
	}
	return 0;
}
int Maxheap::Max()//return maximum of maxheap
{
	return arr[0];
}
int Maxheap::leftchild(int i)//return leftchild of i
{
	return arr[2*i + 1];
}
int Maxheap::rightchild(int i)//return rightchild of i
{
	return arr[2*i + 2];
}
void Maxheap::printArray()
{
	std::cout << "print Array : ";
	for(int i{};i < N;i++)
	{
		if(i==(N-1))
			std::cout << arr[i] << std::endl;
		else
		std::cout << arr[i] << ",";
	}
}
void Maxheap::Heapsort()//sort 
{
	for(int i{};i < N; i++)//sort
	{
		for(int j{};j < N-1 ; j++)
		{
			double temp{};
			if (arr[j] < arr[j+1])
			{
			temp = arr[j+1];
			arr[j+1] = arr[j];
			arr[j] = temp;
		}
		}
    }

}
int Maxheap::operator[](int i)//beracet operator
{
	if(i >= N){
		std::cout << "yor command isout of size and last element of arrary is : arr[" << N-1 <<"]" << std::endl;
		return arr[N-1];
		}
		else
		return arr[i];
}
int Maxheap::getHeight()//return height of maxheap
{
	return std::ceil(log2(N+1)) -1;
}
void Maxheap::Delete()//delete max
{
	std::swap(arr[0],arr[N-1]);
	N=N-1;
	build_Max_Heapify(arr);
}
void Maxheap::add(int i)//add a new node
{
	count++;
	N=count;
	arr[N-1]=i;
	build_Max_Heapify(arr);
}





